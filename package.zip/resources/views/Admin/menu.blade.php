<a href="{{ route('Home') }}">Главная |</a>
<a href="{{ route('About')}}">О проекте |</a>
<a href="{{ route('news.index')}}">Новости |</a>
<a href="{{ route('admin.news')}}">Админка [</a>
<br>
<a href="{{route('admin.categories')}}">CRUD категории |</a>
<a href="{{route('admin.test1')}}">Тест 1 |</a>
<a href="{{route('admin.test2')}}">Тест 2 ]</a>
<br>
