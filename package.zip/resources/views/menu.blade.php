<a href="{{ route('Home') }}">Главная |</a>
<a href="{{ route('About')}}">О проекте |</a>
<a href="{{ route('news.index')}}">Новости |</a>
<a href="{{ route('admin.news')}}">Админка |</a>
<a href="{{ route('login')}}">Авторизация</a>
<br>
