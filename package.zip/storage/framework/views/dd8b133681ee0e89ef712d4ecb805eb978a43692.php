<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##Новости
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(!$news->isPrivate): ?>
                            <h2><?=$news->title?></h2>
                            <div class="card-img" style="background-image: url(<?php echo e($news->image ?? asset('storage/news_default.jpg')); ?>)"></div>
                            <p><?=$news->text?></p>
                        <?php else: ?>
                            Новость приватная. Зарегистрируйтесь для просмотра ..
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/One.blade.php ENDPATH**/ ?>
