<?php $__env->startSection('title', 'Добавление новости'); ?>


<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                        <form method="POST" action="<?php echo e(route('admin.addNews')); ?>">
                            <?php echo csrf_field(); ?>
                                <label for="newsTitle">Заголовок</label>
                                <input name="title" type="text" id="newsTitle" value=" "><br>
                                <label for="newsCategory">Категория новости</label>
                                <select name="category"  id="newsCategory">
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option  value="<?php echo e($item['id']); ?>"><?php echo e($item['category']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <h2>Нет категории</h2>
                                    <?php endif; ?>

                                </select>
                            <br>
                                <label for="newsText">Текст новости</label>
                                <textarea name="text" class="form-control" rows="5" id="newsText"> </textarea>
                                <input type="checkbox" checked name="isPrivate" id="newsPrivate"> Приватная новость
                                </label>
                            <br>
                                <input type="submit"  value="Добавить новость"
                                       id="addNews">

                        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/admin/catCreate.blade.php ENDPATH**/ ?>
