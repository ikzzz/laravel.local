<a href="<?php echo e(route('Home')); ?>">Главная |</a>
<a href="<?php echo e(route('About')); ?>">О проекте |</a>
<a href="<?php echo e(route('news.index')); ?>">Новости |</a>
<a href="<?php echo e(route('admin.news')); ?>">Админка [</a>
<br>
<a href="<?php echo e(route('admin.categories')); ?>">CRUD категории |</a>
<a href="<?php echo e(route('admin.test1')); ?>">Тест 1 |</a>
<a href="<?php echo e(route('admin.test2')); ?>">Тест 2 ]</a>
<br>
<?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/admin/menu.blade.php ENDPATH**/ ?>