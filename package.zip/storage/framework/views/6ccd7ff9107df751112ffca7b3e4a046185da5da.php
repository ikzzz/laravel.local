<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## Новости
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h1>CRUD Категорий новостей</h1>
                        <a href="<?php echo e(route('admin.catCreate')); ?>"><h2>Добавить категорию новостей </h2></a>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <h4>Название : <?php echo e($item->name_category); ?></h4>
                            <h4>Псевдоним: <?php echo e($item->slug_category); ?></h4>
                            <a href="<?php echo e(route('admin.catEdit', $item)); ?>" class="btn btn-success">
                                Edit
                            </a>
                            <a href="<?php echo e(route('admin.catDestroy', $item)); ?>" class="btn btn-danger">
                                Delete
                            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            Нет категорий
                        <?php endif; ?>
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/admin/categories.blade.php ENDPATH**/ ?>