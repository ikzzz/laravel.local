<?php $__env->startSection('title', 'Добавить категорию новостей'); ?>


<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('Admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">

                        <form enctype="multipart/form-data" method="POST" action="<?php if(!$category->id): ?><?php echo e(route('admin.catCreate')); ?><?php else: ?><?php echo e(route('admin.catUpdate', $category)); ?><?php endif; ?>">
    <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="newsTitle">Название категории</label>
                                <?php if($errors->has('name_category')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('name_category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <input name="name_category" type="text" class="form-control" id="newsTitle" value="<?php echo e($category->name_category ?? old('name_category')); ?>">
                            </div>
                            <div class="form-group">
                                <label for="newsTitle">Псевдоним категории(транслитом)</label>
                                <?php if($errors->has('slug_category')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('slug_category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <input name="slug_category" type="text" class="form-control" id="newsTitle" value="<?php echo e($category->slug_category ?? old('slug_category')); ?>">
                            </div>

                            <div class="form-group">
                                <button type="submit" class="form-control">
<?php if($category->id): ?> Изменить <?php else: ?> Добавить <?php endif; ?>
                                </button>

                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/admin/catCreate.blade.php ENDPATH**/ ?>