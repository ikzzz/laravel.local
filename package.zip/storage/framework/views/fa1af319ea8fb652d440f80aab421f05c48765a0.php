<a href="<?php echo e(route('Home')); ?>">Главная |</a>
<a href="<?php echo e(route('About')); ?>">О проекте |</a>
<a href="<?php echo e(route('news.index')); ?>">Новости |</a>
<a href="<?php echo e(route('admin.news')); ?>">Админка |</a>
<a href="<?php echo e(route('login')); ?>">Авторизация</a>
<br>
<?php /**PATH D:\PHP_Dev\OpenServer\domains\laravel.local\resources\views/menu.blade.php ENDPATH**/ ?>